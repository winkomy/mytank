(() => {
  if (!window.gsap || !window.ScrollTrigger) return;
  gsap.registerPlugin(ScrollTrigger);
  const reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  if (reduced) return;

  if (window.Lenis && window.matchMedia('(min-width: 900px) and (pointer: fine)').matches && !navigator.connection?.saveData) {
    const lenis = new Lenis({ duration: 0.85, smoothWheel: true });
    lenis.on('scroll', ScrollTrigger.update);
    gsap.ticker.add(time => lenis.raf(time * 1000));
    gsap.ticker.lagSmoothing(0);
  }

  const story = document.querySelector('.tank-story');
  if (story) {
    const caption = story.querySelector('.stage-caption span');
    ScrollTrigger.create({
      trigger: story,
      start: 'top top',
      end: 'bottom bottom',
      onUpdate(self) {
        const progress = self.progress;
        window.dispatchEvent(new CustomEvent('tank-progress', { detail: progress }));
        caption.textContent = `${String(Math.min(3, Math.floor(progress * 3) + 1)).padStart(2, '0')} / 03`;
      }
    });
  }

  const processImage = document.querySelector('[data-manufacturing-image]');
  document.querySelectorAll('.manufacturing-steps article').forEach(step => {
    ScrollTrigger.create({
      trigger: step,
      start: 'top 65%',
      end: 'bottom 35%',
      onEnter: () => activate(step),
      onEnterBack: () => activate(step)
    });
  });
  function activate(step) {
    document.querySelectorAll('.manufacturing-steps article').forEach(item => item.classList.toggle('is-active', item === step));
    if (!processImage) return;
    const next = `assets/images/${step.dataset.processImage}`;
    if (processImage.getAttribute('src') === next) return;
    gsap.killTweensOf(processImage);
    gsap.to(processImage, {
      opacity: 0.3, duration: 0.17, onComplete() {
        processImage.src = next;
        processImage.onload = () => gsap.to(processImage, { opacity: 1, duration: 0.3 });
      }
    });
  }

  if (window.matchMedia('(pointer: fine)').matches) {
    document.querySelectorAll('.magnetic').forEach(button => {
      const moveX = gsap.quickTo(button, 'x', { duration: 0.28, ease: 'power2.out' });
      const moveY = gsap.quickTo(button, 'y', { duration: 0.28, ease: 'power2.out' });
      button.addEventListener('pointermove', event => {
        const bounds = button.getBoundingClientRect();
        moveX((event.clientX - bounds.left - bounds.width / 2) * 0.08);
        moveY((event.clientY - bounds.top - bounds.height / 2) * 0.08);
      });
      button.addEventListener('pointerleave', () => { moveX(0); moveY(0); });
    });
  }
  window.addEventListener('load', () => ScrollTrigger.refresh(), { once: true });
})();
