"""Create clean upload folders and ZIPs using an explicit file allowlist."""

from pathlib import Path
from shutil import copy2
from zipfile import ZipFile, ZIP_DEFLATED

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "dist"
PUBLIC = ("index.html", "index.htm", "product.htm", "projects.htm", "about.htm",
          "contact.htm", "robots.txt", "sitemap.xml", ".nojekyll", "assets")
REPOSITORY = PUBLIC + ("README.md", ".gitignore", ".github", "docs", "tools")


def package(name, entries):
    paths = []
    for entry in entries:
        source = ROOT / entry
        candidates = sorted(source.rglob("*")) if source.is_dir() else [source]
        for path in candidates:
            if path.is_file() and "__pycache__" not in path.parts and path.suffix != ".pyc":
                paths.append(path)
    folder = OUT / name
    folder.mkdir(parents=True, exist_ok=True)
    with ZipFile(OUT / f"{name}.zip", "w", ZIP_DEFLATED) as archive:
        for source in paths:
            relative = source.relative_to(ROOT)
            target = folder / relative
            target.parent.mkdir(parents=True, exist_ok=True)
            copy2(source, target)
            archive.write(source, relative.as_posix())
    print(f"Created dist/{name}/ and dist/{name}.zip ({len(paths)} files)")


if __name__ == "__main__":
    OUT.mkdir(exist_ok=True)
    package("mytank-site", PUBLIC)
    package("mytank-github-ready", REPOSITORY)
