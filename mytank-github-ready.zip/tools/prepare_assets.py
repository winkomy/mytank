"""Keep the legacy assets intact while producing small, named site images."""

from pathlib import Path
from shutil import copy2
from PIL import Image
import csv

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "legacy-backup" / "index_htm_files"
OUTPUT = ROOT / "assets" / "images"
OUTPUT.mkdir(parents=True, exist_ok=True)


def webp(source, destination, max_width=1800, quality=82):
    with Image.open(SOURCE / source) as image:
        image = image.convert("RGB")
        if image.width > max_width:
            image.thumbnail((max_width, 10000), Image.Resampling.LANCZOS)
        image.save(OUTPUT / destination, "WEBP", quality=quality, method=6)


copy2(SOURCE / "790.png", OUTPUT / "my-tank-mark.png")
for source, destination in {
    "922.jpg": "hero-tank.webp",
    "997@2x.jpg": "product-tanks.webp",
    "978@2x.jpg": "company-tank.webp",
    "979@2x.jpg": "company-installation.webp",
    "927@2x.jpg": "manufacturing-raw.webp",
    "928@2x.jpg": "manufacturing-laser.webp",
    "929@2x.jpg": "manufacturing-panel.webp",
    "930@2x.jpg": "manufacturing-process.webp",
    "931@2x.jpg": "manufacturing-interior.webp",
    "932@2x.jpg": "manufacturing-finished.webp",
}.items():
    webp(source, destination)
webp("929@2x.jpg", "formed-panel.webp")

for number in range(1000, 1048):
    small = f"{number}.jpg"
    large = f"{number}@2x.jpg"
    if (SOURCE / small).exists():
        webp(small, f"project-{number - 999:02d}.webp", quality=78)
        webp(large if (SOURCE / large).exists() else small,
             f"project-{number - 999:02d}-large.webp")

pages = {p.name: p.read_text(encoding="utf-8", errors="replace")
         for p in (ROOT / "legacy-backup").glob("*.htm")}
inventory = ROOT / "docs" / "asset-inventory.csv"
inventory.parent.mkdir(exist_ok=True)
with inventory.open("w", newline="", encoding="utf-8") as output:
    writer = csv.writer(output)
    writer.writerow(("legacy_asset", "bytes", "width", "height", "referenced_by"))
    for asset in sorted(SOURCE.iterdir()):
        if not asset.is_file():
            continue
        width = height = ""
        if asset.suffix.lower() in {".jpg", ".png", ".gif", ".ico"}:
            try:
                with Image.open(asset) as image:
                    width, height = image.size
            except OSError:
                pass
        used = ", ".join(name for name, html in pages.items() if asset.name in html)
        writer.writerow((asset.name, asset.stat().st_size, width, height, used))

print(f"Prepared {len(list(OUTPUT.iterdir()))} optimized images and {inventory}")
