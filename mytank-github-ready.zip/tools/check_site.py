"""Small deployment check for the generated static pages."""

from html.parser import HTMLParser
from pathlib import Path
from urllib.parse import urlsplit

root = Path(__file__).resolve().parents[1]
pages = ("index", "product", "projects", "about", "contact")


class Page(HTMLParser):
    def __init__(self):
        super().__init__()
        self.h1 = 0
        self.refs = []
        self.canonical = False

    def handle_starttag(self, tag, attributes):
        attrs = dict(attributes)
        self.h1 += tag == "h1"
        if tag == "link" and attrs.get("rel") == "canonical":
            self.canonical = True
        for key in ("src", "href"):
            if key in attrs:
                self.refs.append(attrs[key])


for name in pages:
    path = root / f"{name}.htm"
    page = Page()
    page.feed(path.read_text(encoding="utf-8"))
    assert page.h1 == 1 and page.canonical, f"Invalid headings or canonical: {path.name}"
    if (root / "legacy-backup").exists():
        assert (root / "legacy-backup" / path.name).exists(), f"Original not backed up: {path.name}"
    for ref in page.refs:
        parsed = urlsplit(ref)
        if not parsed.scheme and not parsed.netloc and parsed.path:
            assert (root / parsed.path).exists(), f"Missing local reference: {path.name} → {ref}"

assert (root / "projects.htm").read_text(encoding="utf-8").count('class="project-card"') == 48
print("Five pages, local references and 48 gallery images: OK")
