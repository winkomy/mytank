# October UI update

## Design

Silver and white surfaces, charcoal type, rust-orange accents, bold sans-serif headings, a panoramic home photograph and an overlaid specification rail. The home system navigation links assembly, engineering, manufacturing and real installations. Inner-page headings are scaled to retain readable line lengths.

## Motion

Photographic hero reveal, staggered title entrance, section reveals, illustrated panel separation/reassembly on scroll, interactive material grades, manufacturing photo transitions and mobile menu transitions. Mobile assembly keeps the model visible above the explanatory text. Motion honors reduced-motion preferences; original product photographs remain the WebGL fallback.

## Files

Two allowlisted packages: complete repository and public website only. Both exclude the pricing workbook, original legacy folders and existing duplicate archives. Original files remain locally. A manual GitHub Pages workflow and an index.html homepage are included.

## Checks performed

- Visually reviewed all five pages at 1440 x 900 and 390 x 844.
- Checked document width against viewport width; no horizontal document overflow found.
- Verified mobile menu open/close, grade selection, gallery reveal from 12 to 24 photographs, next photograph and dialog close.
- Confirmed the 3D renderer loads and panel positions change on scroll.
- Verified five page headings/canonical links and local references using the existing checker.
- Inspected both ZIP manifests: required homepage/routes and GitHub workflow are present; spreadsheets and legacy assets are absent.

The manual Pages workflow has not run in a remote repository. The enquiry still prepares an email draft. Original claims awaiting confirmation remain documented in content-review.md.
