# MY TANK source content review

The exact legacy pages and every original asset are preserved in `legacy-backup/`.
The new pages retain supported dimensions, grades, process stages, applications,
company identity, and contact details. These source statements need owner review
before being presented as MY TANK product or company claims.

| Source | CONTENT REVIEW REQUIRED |
| --- | --- |
| `about.htm` | Company policy names **Alstore** three times and **Pacific Belle** once. The complete policy remains in `legacy-backup/about.htm`. Confirm authorship and the wording before publishing it as MY TANK policy. |
| `product.htm` | Cleaning copy names **Sunnik**. Confirm whether the statement applies to MY TANK tanks. |
| `product.htm` | “6 layer technology”, “100% eco friendly”, “Malaysia pressure equipments directives”, “zero maintenance” for 10 years, “germ free”, and temperature claims need product evidence. The complete original copy remains in `legacy-backup/product.htm`. |
| `contact.htm` | The enquiry iframe submits to `myglobalyachtrental.com`; the new site uses an honest email draft fallback until an MY TANK form endpoint is supplied. |
| `contact.htm` | Confirm the embedded map still points to the MY TANK office at Solaris Mont Kiara. |

The new site does not assign names, clients, capacities, or locations to the
project photographs because the source provides none.
