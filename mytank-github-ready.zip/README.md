# MY TANK website

A responsive static website with a silver industrial catalogue design, rust-orange accents, real MY TANK photographs, and accessible motion. No Node.js installation or frontend build dependencies are required.

## Open locally

```sh
python -m http.server 8765 --bind 127.0.0.1
```

Open http://127.0.0.1:8765/. Serve the files over HTTP so the optional 3D module loads correctly.

## Upload to GitHub

Use the contents of **dist/mytank-github-ready/**, or extract **dist/mytank-github-ready.zip**. The ZIP contains the complete repository, including hidden `.github`, `.gitignore`, and `.nojekyll` files. Keep these when copying. Do not upload the ZIP itself as your website source.

1. Create an empty GitHub repository and clone it using GitHub Desktop.
2. Copy the contents of the clean GitHub folder into the cloned repository folder.
3. Commit and push with GitHub Desktop.
4. For hosting, open repository **Settings > Pages** and select **GitHub Actions** as the source.
5. Open **Actions > Deploy MY TANK to GitHub Pages > Run workflow**.

The included workflow deploys only public website files. It runs manually; pushing source alone does not deploy. Configuration follows [GitHub's custom Pages workflow guide](https://docs.github.com/en/pages/getting-started-with-github-pages/using-custom-workflows-with-github-pages).

No remote repository has been created or uploaded by this local build. The workflow must be run in your repository before a published URL exists.

## File organization

```text
index.html                  Homepage for GitHub Pages
index.htm                   Existing production homepage route
product.htm                 Product information
projects.htm                48 authentic installation photographs
about.htm                   Company information
contact.htm                 Enquiry and contact details
assets/
  css/                      Shared responsive styles
  js/                       UI controls, motion and optional 3D assembly
  images/                   Optimized real site photography
  fonts/                    Local font files
  vendor/                   Local motion libraries
  models/                   Optional engineering model instructions
tools/                      Page generator and packaging scripts
docs/                       Asset inventory and owner content review
.github/workflows/          Manual GitHub Pages deployment
```

**Local originals:** `legacy-backup/`, `index_htm_files/`, old ZIPs and spreadsheets remain in the working folder. `.gitignore` excludes them. The packaging script uses an explicit allowlist and excludes them from both upload packages. The pricing workbook is not website content.

## Edit and rebuild

Edit content and shared markup in `tools/build_site.py`, styles in `assets/css/site.css`, and interactions in `assets/js/`.

```sh
python tools/build_site.py
python tools/package_site.py
```

The generator writes five `.htm` pages plus `index.html`. Packaging creates:

- `dist/mytank-github-ready/` and its ZIP: complete clean repository.
- `dist/mytank-site/` and its ZIP: public files for a web host.

An optional local reference check is available with `python tools/check_site.py`. Existing optimized photographs are committed and require no regeneration. `tools/prepare_assets.py` is optional and requires Pillow plus the locally retained original `legacy-backup/index_htm_files/` folder, which is intentionally absent from the GitHub package.

## Motion and accessibility

The homepage includes a staged photographic reveal, scroll-driven illustrative panel assembly, and manufacturing photo changes. Shared section reveals, menu transitions, gallery interactions and grade controls work across the site. Reduced-motion preferences disable decorative animation; real photos remain as the 3D fallback. Content and links remain available without JavaScript.

## Search and hosting

Page titles, descriptions, canonical URLs, Organization structured data, sitemap and robots file are retained. Production SEO URLs target `https://mytank.com.my`; relative asset paths also work under a GitHub Pages project URL. When using Pages as production hosting, configure your owned domain in Pages settings. If the intended production domain changes, update `SITE` in `tools/build_site.py`, `sitemap.xml` and `robots.txt` together.

## Existing implementation limits

- The enquiry form prepares an email draft. Set the owned HTTPS `FORM_ENDPOINT` in `assets/js/site.js` for direct online submissions.
- The 3D tank is an illustrative assembly model, not a certified engineering drawing. See `assets/models/README.md` for supplying a real GLB.
- Source claims awaiting owner confirmation are documented in `docs/content-review.md`. Original pages remain in the local backup.
- Pinned local library versions are listed in `assets/vendor/README.md`; preserve their license headers.
