No owner-approved 3D tank model was present in the source site.

The homepage renders an illustrative procedural modular tank. To use a real
model, place `tank.glb` here and set `data-model="assets/models/tank.glb"` on
the homepage tank stage in `tools/build_site.py`, then rebuild. Name its
individual panel meshes `panel-*` for the scroll separation to animate them.
If the model fails to load or lacks panel meshes, the procedural model remains.
