import * as THREE from '../vendor/three.module.js';

export function mountTank(stage) {
  const canvas = stage.querySelector('canvas');
  let renderer;
  try {
    renderer = new THREE.WebGLRenderer({ canvas, alpha: true, antialias: true, powerPreference: 'low-power' });
  } catch {
    return; // The photograph remains visible if WebGL is unavailable.
  }
  const mobile = window.matchMedia('(max-width: 800px)').matches;
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, mobile ? 1.25 : 1.7));
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.35;

  const scene = new THREE.Scene();
  const camera = new THREE.PerspectiveCamera(35, 1, 0.1, 100);
  camera.position.set(mobile ? 6.8 : 6, 4.2, 7.3);
  camera.lookAt(0, 0, 0);
  scene.add(new THREE.HemisphereLight(0xdce7ea, 0x303235, 2.1));
  const key = new THREE.DirectionalLight(0xffffff, 4.2);
  key.position.set(-5, 8, 7);
  scene.add(key);
  const rim = new THREE.DirectionalLight(0xd2e2f0, 2.2);
  rim.position.set(5, 2, -6);
  scene.add(rim);

  const tank = new THREE.Group();
  let activeTank = tank;
  scene.add(tank);
  const panels = [];
  const size = 0.82;
  const columns = mobile ? 2 : 4;
  const rows = mobile ? 2 : 3;
  const depth = 2;
  const width = columns * size;
  const height = rows * size;
  const length = depth * size;
  const steel = new THREE.MeshStandardMaterial({ color: 0xd1d8d5, metalness: 0.35, roughness: 0.38 });
  const frame = new THREE.MeshStandardMaterial({ color: 0x747d78, metalness: 0.35, roughness: 0.42 });
  const plateGeometry = new THREE.BoxGeometry(size * 0.96, size * 0.96, 0.04);
  const ribGeometry = new THREE.BoxGeometry(size * 1.22, 0.022, 0.025);
  const edgeGeometry = new THREE.BoxGeometry(size * 0.96, 0.028, 0.055);

  function addPanel(position, rotation, outward) {
    const panel = new THREE.Group();
    panel.position.copy(position);
    panel.rotation.set(...rotation);
    panel.add(new THREE.Mesh(plateGeometry, steel));
    for (const angle of [Math.PI / 4, -Math.PI / 4]) {
      const rib = new THREE.Mesh(ribGeometry, frame);
      rib.position.z = 0.039;
      rib.rotation.z = angle;
      panel.add(rib);
    }
    for (const y of [-size * 0.47, size * 0.47]) {
      const edge = new THREE.Mesh(edgeGeometry, frame);
      edge.position.set(0, y, 0.035);
      panel.add(edge);
    }
    tank.add(panel);
    panels.push({ mesh: panel, base: position.clone(), offset: outward.clone().multiplyScalar(mobile ? 0.65 : 1.08) });
  }
  for (let x = 0; x < columns; x++) for (let y = 0; y < rows; y++) {
    const px = (x - (columns - 1) / 2) * size;
    const py = (y - (rows - 1) / 2) * size;
    addPanel(new THREE.Vector3(px, py, length / 2), [0, 0, 0], new THREE.Vector3(px * 0.16, py * 0.12, 1));
    addPanel(new THREE.Vector3(px, py, -length / 2), [0, Math.PI, 0], new THREE.Vector3(px * 0.16, py * 0.12, -1));
  }
  for (let z = 0; z < depth; z++) for (let y = 0; y < rows; y++) {
    const pz = (z - (depth - 1) / 2) * size;
    const py = (y - (rows - 1) / 2) * size;
    addPanel(new THREE.Vector3(width / 2, py, pz), [0, Math.PI / 2, 0], new THREE.Vector3(1, py * 0.12, pz * 0.16));
    addPanel(new THREE.Vector3(-width / 2, py, pz), [0, -Math.PI / 2, 0], new THREE.Vector3(-1, py * 0.12, pz * 0.16));
  }
  for (let x = 0; x < columns; x++) for (let z = 0; z < depth; z++) {
    const px = (x - (columns - 1) / 2) * size;
    const pz = (z - (depth - 1) / 2) * size;
    addPanel(new THREE.Vector3(px, height / 2, pz), [-Math.PI / 2, 0, 0], new THREE.Vector3(px * 0.12, 1, pz * 0.12));
    addPanel(new THREE.Vector3(px, -height / 2, pz), [Math.PI / 2, 0, 0], new THREE.Vector3(px * 0.12, -1, pz * 0.12));
  }

  let scheduled = false;
  function render() {
    scheduled = false;
    try {
      renderer.render(scene, camera);
      stage.dataset.ready = '';
    } catch {
      stage.removeAttribute('data-ready');
    }
  }
  function schedule() {
    if (!scheduled) {
      scheduled = true;
      requestAnimationFrame(render);
    }
  }
  function resize() {
    const bounds = stage.getBoundingClientRect();
    if (!bounds.width || !bounds.height) return;
    renderer.setSize(bounds.width, bounds.height, false);
    camera.aspect = bounds.width / bounds.height;
    camera.updateProjectionMatrix();
    schedule();
  }
  const resizeObserver = new ResizeObserver(resize);
  resizeObserver.observe(stage);
  resize();

  let drag = 0;
  let pointerX = null;
  canvas.style.touchAction = 'pan-y';
  canvas.addEventListener('pointerdown', event => { pointerX = event.clientX; canvas.setPointerCapture(event.pointerId); });
  canvas.addEventListener('pointermove', event => {
    if (pointerX === null) return;
    drag += (event.clientX - pointerX) * 0.004;
    pointerX = event.clientX;
    activeTank.rotation.y = -0.25 + drag;
    schedule();
  });
  canvas.addEventListener('pointerup', () => { pointerX = null; });
  canvas.addEventListener('pointercancel', () => { pointerX = null; });

  function onProgress(event) {
    const progress = event.detail;
    const split = progress < 0.52 ? progress / 0.52 : (1 - progress) / 0.48;
    const eased = Math.max(0, Math.min(1, split));
    const distance = eased * eased * (3 - 2 * eased);
    for (const panel of panels) panel.mesh.position.copy(panel.base).addScaledVector(panel.offset, distance);
    activeTank.rotation.y = -0.25 + drag + progress * 0.22;
    activeTank.rotation.x = -0.06 + progress * 0.07;
    schedule();
  }
  window.addEventListener('tank-progress', onProgress);
  canvas.addEventListener('webglcontextlost', () => stage.removeAttribute('data-ready'));
  schedule();

  // CONTENT REVIEW REQUIRED: no tank.glb exists in the source. Set data-model to
  // assets/models/tank.glb when an owner-approved model is supplied. It must have
  // panel meshes named "panel-*" for exploded animation; otherwise this model stays.
  const modelUrl = stage.dataset.model;
  if (modelUrl) {
    import('../vendor/GLTFLoader.js').then(({ GLTFLoader }) => {
      new GLTFLoader().load(modelUrl, gltf => {
        const modelPanels = [];
        gltf.scene.traverse(node => {
          if (node.isMesh && /^panel[-_]/i.test(node.name)) modelPanels.push(node);
        });
        if (!modelPanels.length) return;
        const bounds = new THREE.Box3().setFromObject(gltf.scene);
        const center = bounds.getCenter(new THREE.Vector3());
        const scale = 3.2 / bounds.getSize(new THREE.Vector3()).length();
        gltf.scene.position.sub(center.multiplyScalar(scale));
        gltf.scene.scale.setScalar(scale);
        scene.remove(tank);
        scene.add(gltf.scene);
        activeTank = gltf.scene;
        panels.length = 0;
        for (const mesh of modelPanels) {
          const base = mesh.position.clone();
          const offset = base.clone().normalize().multiplyScalar(0.9);
          panels.push({ mesh, base, offset });
        }
        schedule();
      }, undefined, () => {});
    }).catch(() => {});
  }
  window.addEventListener('pagehide', () => { resizeObserver.disconnect(); renderer.dispose(); }, { once: true });
}
