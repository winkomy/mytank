(() => {
  // Content remains visible when scripts or motion are disabled.
  if (!window.matchMedia('(prefers-reduced-motion: reduce)').matches && 'IntersectionObserver' in window) {
    const reveals = new IntersectionObserver(entries => entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('is-visible');
        reveals.unobserve(entry.target);
      }
    }), { threshold: 0.08 });
    document.querySelectorAll('.section-heading-row, .technical-grid > div, .two-column > div, .advantage-grid article, .editorial-columns article, .company-grid > div, .preview-grid figure, .inner-hero-grid > div, .contact-hero-grid > div').forEach(item => {
      item.classList.add('reveal-ready');
      reveals.observe(item);
    });
  }
  const header = document.querySelector('.site-header');
  const menuButton = document.querySelector('.menu-toggle');
  const mobileMenu = document.querySelector('.mobile-menu');
  const syncHeader = () => header?.classList.toggle('is-scrolled', window.scrollY > 32);
  syncHeader();
  window.addEventListener('scroll', syncHeader, { passive: true });

  function setMenu(open) {
    if (!menuButton || !mobileMenu) return;
    menuButton.setAttribute('aria-expanded', String(open));
    menuButton.setAttribute('aria-label', open ? 'Close menu' : 'Open menu');
    mobileMenu.hidden = !open;
    document.body.classList.toggle('menu-open', open);
    if (open) mobileMenu.querySelector('a')?.focus();
  }
  menuButton?.addEventListener('click', () => setMenu(menuButton.getAttribute('aria-expanded') !== 'true'));
  mobileMenu?.addEventListener('click', event => {
    if (event.target.closest('a')) setMenu(false);
  });
  document.addEventListener('keydown', event => {
    if (event.key === 'Escape' && menuButton?.getAttribute('aria-expanded') === 'true') {
      setMenu(false);
      menuButton.focus();
    }
  });
  window.addEventListener('resize', () => {
    if (window.innerWidth > 1100) setMenu(false);
  });

  document.querySelectorAll('.grade-tabs').forEach(tabs => {
    const buttons = [...tabs.querySelectorAll('[role="tab"]')];
    const panel = tabs.nextElementSibling;
    function select(button) {
      buttons.forEach(item => {
        const active = item === button;
        item.setAttribute('aria-selected', String(active));
        item.tabIndex = active ? 0 : -1;
      });
      panel.querySelector('[data-grade-value]').textContent = button.dataset.grade;
    }
    tabs.addEventListener('click', event => {
      const button = event.target.closest('[role="tab"]');
      if (button) select(button);
    });
    tabs.addEventListener('keydown', event => {
      if (!['ArrowLeft', 'ArrowRight', 'Home', 'End'].includes(event.key)) return;
      event.preventDefault();
      const current = buttons.indexOf(document.activeElement);
      const next = event.key === 'Home' ? 0 : event.key === 'End' ? buttons.length - 1 :
        (current + (event.key === 'ArrowRight' ? 1 : -1) + buttons.length) % buttons.length;
      select(buttons[next]);
      buttons[next].focus();
    });
  });

  const showMore = document.querySelector('[data-show-more]');
  const projectCards = [...document.querySelectorAll('.project-card')];
  showMore?.addEventListener('click', () => {
    projectCards.filter(card => card.hidden).slice(0, 12).forEach(card => card.hidden = false);
    if (!projectCards.some(card => card.hidden)) showMore.hidden = true;
  });
  const lightbox = document.querySelector('.lightbox');
  if (lightbox) {
    const image = lightbox.querySelector('img');
    const caption = lightbox.querySelector('.lightbox-caption');
    let current = 0;
    function display(index) {
      current = (index + projectCards.length) % projectCards.length;
      const card = projectCards[current];
      image.src = card.href;
      image.alt = card.querySelector('img').alt;
      caption.textContent = `INSTALLATION / ${String(current + 1).padStart(2, '0')}`;
    }
    document.querySelector('#project-grid')?.addEventListener('click', event => {
      const card = event.target.closest('.project-card');
      if (!card) return;
      event.preventDefault();
      display(projectCards.indexOf(card));
      lightbox.showModal();
    });
    lightbox.querySelector('.lightbox-close').addEventListener('click', () => lightbox.close());
    lightbox.querySelector('.lightbox-prev').addEventListener('click', () => display(current - 1));
    lightbox.querySelector('.lightbox-next').addEventListener('click', () => display(current + 1));
    lightbox.addEventListener('click', event => {
      if (event.target === lightbox) lightbox.close();
    });
    lightbox.addEventListener('keydown', event => {
      if (event.key === 'ArrowLeft') display(current - 1);
      if (event.key === 'ArrowRight') display(current + 1);
    });
    lightbox.addEventListener('close', () => image.removeAttribute('src'));
  }

  const FORM_ENDPOINT = ''; // Set to an MY TANK-controlled HTTPS endpoint when available.
  const form = document.querySelector('#enquiry-form');
  form?.addEventListener('submit', async event => {
    event.preventDefault();
    const status = form.querySelector('.form-status');
    const data = Object.fromEntries(new FormData(form));
    if (!FORM_ENDPOINT) {
      const body = Object.entries(data).map(([key, value]) => `${key.replace(/^./, char => char.toUpperCase())}: ${value}`).join('\n');
      status.textContent = 'Your email app will open with a draft. Please send it there; this website has not submitted your enquiry.';
      window.location.href = `mailto:lee@mytank.com.my?subject=${encodeURIComponent('MY TANK project enquiry')}&body=${encodeURIComponent(body)}`;
      return;
    }
    const button = form.querySelector('button[type="submit"]');
    button.disabled = true;
    status.textContent = 'Sending your enquiry…';
    try {
      const response = await fetch(FORM_ENDPOINT, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(data) });
      if (!response.ok) throw new Error('Submission failed');
      status.textContent = 'Your enquiry was sent. Thank you.';
      form.reset();
    } catch {
      status.textContent = 'Your enquiry could not be sent. Please email lee@mytank.com.my or use WhatsApp.';
    } finally {
      button.disabled = false;
    }
  });

  document.querySelectorAll('[data-year]').forEach(node => node.textContent = new Date().getFullYear());
  const stage = document.querySelector('[data-tank-stage]');
  if (stage && !window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
    const observer = new IntersectionObserver(entries => {
      if (!entries[0].isIntersecting) return;
      observer.disconnect();
      import('./tank-3d.js?v=14').then(module => module.mountTank(stage)).catch(() => {});
    }, { rootMargin: '300px' });
    observer.observe(stage);
  }
})();
